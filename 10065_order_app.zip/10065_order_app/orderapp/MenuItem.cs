namespace orderapp;

public class MenuItem
{
    public string Name { get; set; }
    public decimal Price { get; set; }
    public string ImageSource { get; set; }
}